<div align='center'>
  
# listen-ytx 🗣️📝

### Listen is a sleek, command-line-fist to-do list📝 manager built for powerful users. It lets you manage you daily task directly from the CLI with intutive commands that feels like natural language.

</div>
